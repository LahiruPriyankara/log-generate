package com.lhu.loggenerate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogGenerateApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogGenerateApplication.class, args);
	}

}
