package com.lhu.loggenerate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogGenerateApplicationTests {

	@Test
	void contextLoads() {
	}

}
